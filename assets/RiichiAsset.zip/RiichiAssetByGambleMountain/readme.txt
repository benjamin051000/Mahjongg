Find the latest version here: https://gamblemountain.itch.io/riichi-asset

Thanks for using my asset pack for Riichi Mahjong. 

The sheet is broken into 32x32 tiles. 

License:
[MIT](https://choosealicense.com/licenses/mit/)